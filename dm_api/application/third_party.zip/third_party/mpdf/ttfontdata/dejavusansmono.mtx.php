<?php
$name='DejaVuSansMono';
$type='TTF';
$desc=array (
  'Ascent' => 928,
  'Descent' => -236,
  'CapHeight' => 928,
  'Flags' => 5,
  'FontBBox' => '[-558 -375 718 1042]',
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 602,
);
$up=-63;
$ut=44;
$ttffile='C:/xampp/htdocs/ralin/application/third_party/mpdf/ttfonts/DejaVuSansMono.ttf';
$TTCfontID='0';
$originalsize=322524;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusansmono';
$panose=' 0 0 2 b 6 9 3 8 4 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>